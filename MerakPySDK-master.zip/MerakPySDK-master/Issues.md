* <s>try not defining class if there are many staticmethods, using module may be sufficient</s>
* <s>do not always follow js-stellar-base's practice</s>
* <s>each class should have a `__init__` explicitly</s>
* using `if __name__ == '__main__':` idiom for a poor man's unittest
* try adding more possible exception handling; exit program before being late
* <s>try not using `memoryview` </s>
* <s>do not use builtin names</s>