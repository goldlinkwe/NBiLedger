# Services package

Packages contained by this package represent the long-running applications developed for the Stellar network.

See [godoc](https://godoc.org/github.com/stellar/go/services) for details about each application.