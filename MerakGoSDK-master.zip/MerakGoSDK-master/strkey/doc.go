// Package strkey is an implementation of StrKey, the address scheme for the
// StellarNetwork.
package strkey
