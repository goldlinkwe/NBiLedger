This directory contains simple go programs and/or bash scripts that aid in the development of this repo.  Build scripts, linting scripts, etc.


## `build_release_artifacts`

This simple go application that travis uses to build our release packages.