# How to contribute

Please read the [Contribution Guide](https://github.com/stellar/docs/blob/master/CONTRIBUTING.md).

Then please [sign the Contributor License Agreement](https://docs.google.com/forms/d/1g7EF6PERciwn7zfmfke5Sir2n10yddGGSXyZsq98tVY/viewform?usp=send_form).

