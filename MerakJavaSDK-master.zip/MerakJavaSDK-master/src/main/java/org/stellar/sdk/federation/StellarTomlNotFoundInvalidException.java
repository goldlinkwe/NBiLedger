package org.stellar.sdk.federation;

/**
 * Stellar.toml file was not found or was malformed.
 */
public class StellarTomlNotFoundInvalidException extends RuntimeException {
}
