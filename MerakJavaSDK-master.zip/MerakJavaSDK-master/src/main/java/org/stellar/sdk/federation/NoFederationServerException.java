package org.stellar.sdk.federation;

/**
 * Federation server was not found in stellar.toml file.
 */
public class NoFederationServerException extends RuntimeException {
}
