package org.stellar.sdk.federation;

/**
 * Federation server responded with error
 */
public class ServerErrorException extends RuntimeException {
}
