package org.stellar.sdk.responses.operations;

/**
 * Represents Inflation operation response.
 * @see <a href="https://www.stellar.org/developers/horizon/reference/resources/operation.html" target="_blank">Operation documentation</a>
 * @see org.stellar.sdk.requests.OperationsRequestBuilder
 * @see org.stellar.sdk.Server#operations()
 */
public class InflationOperationResponse extends OperationResponse {
}
