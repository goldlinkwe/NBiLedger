package org.stellar.sdk.federation;

/**
 * Federation server is invalid (malformed URL, not HTTPS, etc.)
 */
public class FederationServerInvalidException extends RuntimeException {
}
