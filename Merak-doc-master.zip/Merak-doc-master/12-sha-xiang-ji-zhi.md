## [1.1沙箱环境](#)

| **环境说明** | **访问地址** |
| :--- | :--- |
| 测试沙箱环境URL | [http://api.t.nbile.com/](#) |
| network\_passphrase | Public Global NBiLe Network 201612 |



