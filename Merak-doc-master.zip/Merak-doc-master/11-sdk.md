提供JS、Go、Java、Ruby、Python和C\#等版本的SDK。SDK下载地址为：

JavaScript语言版本SDK：[https://github.com/NBiLe/MerakJSSDK](https://github.com/NBiLe/MerakJSSDK)

Go语言版本SDK：[https://github.com/NBiLe/MerakGoSDK](https://github.com/NBiLe/MerakGoSDK)

Java语言版本SDK：[https://github.com/NBiLe/MerakJavaSDK](https://github.com/NBiLe/MerakJavaSDK)

Ruby语言版本SDK：[https://github.com/NBiLe/MerakRubySDK](https://github.com/NBiLe/MerakRubySDK)

Python语言版本SDK：[https://github.com/NBiLe/MerakPySDK](https://github.com/NBiLe/MerakPySDK)

C\#语言版本SDK：[https://github.com/NBiLe/MerakCsharpSDK](https://github.com/NBiLe/MerakCsharpSDK)

