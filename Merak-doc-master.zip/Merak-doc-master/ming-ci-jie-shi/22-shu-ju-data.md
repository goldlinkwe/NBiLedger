## [2.2数据Data](/ming-ci-jie-shi/22-shu-ju-data.md)

NBIle区块链网络中，每个账户可以存储key/value格式的数据。其中key是Base64编码字符串。

