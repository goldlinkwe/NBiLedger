返回格式是JSON数据格式。数据格式采用HAL，具体细节请参考

[http://stateless.co/hal\_specification.html](http://stateless.co/hal_specification.html)

