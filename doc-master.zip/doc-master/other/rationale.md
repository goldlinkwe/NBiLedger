
There were a lot of design decisions that went into making Stellar. Here are some of the reasons behind why we did what we did.

# Why XDR?
3 reasons:
- XDR has a canonical bit-level encoding.
- It is an internet standard.
- It supports disjoint unions (sum types).
