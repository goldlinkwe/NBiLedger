// Package simplepath provides an implementation of paths.Finder that performs
// a breadth first search for paths against a stellar-core's database
package simplepath
