// This package contains the Server Sent Events implementation used by
// horizon.
package sse
