package horizon

//go:generate go-codegen
//go:generate gofmt -w main_generated.go
