// Package paths provides utilities and facilities for payment paths as needed by horizon. Most
// importantly, it provides the Finder interface, allowing for pluggable path finding back ends.
package paths
