// Package actions provides the infrastructure for defining and executing
// actions (code that is triggered in response to an client request) on horizon.
// At present it allows for defining actions that can respond using JSON or SSE.
package actions
