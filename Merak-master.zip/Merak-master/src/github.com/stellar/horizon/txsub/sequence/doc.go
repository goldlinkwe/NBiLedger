// Package sequence providers helpers to manage sequence numbers on behalf of horizon clients.
// See Manager for more details on the api.
package sequence
