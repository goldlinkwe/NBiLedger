#define STELLAR_CORE_VERSION "unknown-msvc"
