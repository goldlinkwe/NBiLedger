# How to contribute

Your contributions to the Stellar network will help improve the world’s financial
infrastructure, faster.

We want to make it as easy as possible to contribute changes that
help the Stellar network grow and thrive. There are a few guidelines that we
ask contributors to follow so that we can merge your changes quickly.

## Getting Started

* Create a GitHub issue for your contribution, assuming one does not already exist.
  * Clearly describe the issue including steps to reproduce if it is a bug.
* Fork the repository on GitHub

## Making Changes

* Create a topic branch from where you want to base your work.
  * This is usually the master branch.
  * Please avoid working directly on the `master` branch.
* Make sure you have added the necessary tests for your changes, and make sure all tests pass.

## Submitting Changes

* <a href="https://docs.google.com/forms/d/1g7EF6PERciwn7zfmfke5Sir2n10yddGGSXyZsq98tVY/viewform?usp=send_form">Sign the Contributor License Agreement</a>
* Push your changes to a topic branch in your fork of the repository.
* Submit a pull request to the corresponding repository in the Stellar organization.
 * Include a descriptive [commit message](https://github.com/erlang/otp/wiki/Writing-good-commit-messages).
 * Changes contributed via pull request should focus on a single issue at a time.
 * Rebase your local changes against the master branch. Resolve any conflicts that arise.
 
At this point you're waiting on us. We like to at least comment on pull requests within three 
business days. We may suggest some changes or improvements or alternatives.

# Additional Resources

* [Bug tracker (Github)](https://github.com/stellar/ruby-stellar-lib/issues)
* <a href="https://docs.google.com/forms/d/1g7EF6PERciwn7zfmfke5Sir2n10yddGGSXyZsq98tVY/viewform?usp=send_form">Contributor License Agreement</a>
* #stellar-dev IRC channel on freenode.org and Slack chat on stellar-public.slack.com


This document is inspired by:

https://github.com/puppetlabs/puppet/blob/master/CONTRIBUTING.md 

https://github.com/thoughtbot/factory_girl_rails/blob/master/CONTRIBUTING.md 

https://github.com/rust-lang/rust/blob/master/CONTRIBUTING.md